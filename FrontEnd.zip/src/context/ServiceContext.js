import React from "react";

function ServiceContext() {
  return <div>ServiceContext</div>;
}

export default ServiceContext;
