import React from 'react'

function BookingContext() {
  return (
    <div>BookingContext</div>
  )
}

export default BookingContext