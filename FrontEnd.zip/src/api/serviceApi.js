import React from 'react'

function serviceApi() {
  return (
    <div>serviceApi</div>
  )
}

export default serviceApi