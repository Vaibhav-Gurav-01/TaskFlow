import React from "react";

function authApi() {
  return <div>authApi</div>;
}

export default authApi;
