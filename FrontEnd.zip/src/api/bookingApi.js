

import React from 'react'

function bookingApi() {
  return (
    <div>bookingApi</div>
  )
}

export default bookingApi