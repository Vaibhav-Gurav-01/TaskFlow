import React from "react";

function paymentApi() {
  return <div>paymentApi</div>;
}

export default paymentApi;
