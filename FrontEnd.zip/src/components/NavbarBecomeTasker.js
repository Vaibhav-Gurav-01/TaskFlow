import React from "react";
import { Link } from "react-router-dom";

const NavbarBecomeTasker = () => {
  return (
    <header class="text-center py-3">
      <h1 class="text-success">taskrabbit</h1>
    </header>
  );
};

export default NavbarBecomeTasker;
