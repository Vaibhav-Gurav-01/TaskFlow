import React from "react";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "../assets/styles/Footer.css";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-section">
        <div className="footer-social">
          <p>Follow us! We're friendly:</p>
          <div className="social-icons">
            <a href="https://www.linkedin.com/" target="_blank" aria-label="Facebook">
              <i className="fab fa-linkedin"></i>
            </a>
            <a href="https://www.facebook.com/"  target="_blank" aria-label="X">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="https://www.instagram.com/"  target="_blank" aria-label="Instagram">
              <i className="fab fa-instagram"></i>
            </a>

<h2> <p className="logo-linkfooter">One-Click Platform</p></h2>
           
          </div>
        </div>

        <div className="footer-links">
          <div className="footer-column">
            <h4>Discover</h4>
            <ul>
              <li>
                <a href="#">Become a Tasker</a>
              </li>
              <li>
                <a href="#">Services By City</a>
              </li>
              <li>
                <a href="#">Services Nearby</a>
              </li>
              <li>
                <a href="#">All Services</a>
              </li>
              <li>
                <a href="#">Elite Taskers</a>
              </li>
              <li>
                <a href="#">Help</a>
              </li>
            </ul>
          </div>
          <div className="footer-column">
            <h4>Company</h4>
            <ul>
              <li>
                <a href="#">About Us</a>
              </li>
              <li>
                <a href="#">Careers</a>
              </li>
                            <li>
                <a href="#">Blog</a>
              </li>
              <li>
                <a href="#">Terms & Privacy</a>
              </li>
              
              <li>
                <a href="#">Do Not Sell My Personal Information</a>
              </li>
              <li>
                <a href="#">Legal</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="footer-app">
          <h4>Download our app</h4>
          
          <div className="app-links">
            <a
              href="https://www.apple.com/in/app-store/"
              target="_blank"
              rel="noopener noreferrer"
              className="app-store"
            >
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/6/67/App_Store_%28iOS%29.svg"
                alt="App Store"
                style={{ width: "100px", height: "250px" }}
              />
            </a>
            <a
              href="https://play.google.com/store/apps?hl=en"
              target="_blank"
              rel="noopener noreferrer"
              className="google-play"
            >
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/78/Google_Play_Store_badge_EN.svg/512px-Google_Play_Store_badge_EN.svg.png"
                alt="Google Play"
                style={{ width: "200px", height: "100px" }}
              />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
