import React from 'react';
import "../assets/styles/Transaction.css";

function Transaction() {
    return (
        <div className='form-component'>
            <h2>Transactions</h2>
            <p>No transactions available</p>
        </div>
    );
}

export default Transaction;
