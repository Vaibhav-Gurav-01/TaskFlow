import React from "react";
import { Link } from "react-router-dom";

const ServiceCard = ({ service }) => {
  return (
    <div className="service-card">
      <h3>{service.name}</h3>
      <p>{service.description}</p>
      <Link to={`/services/${service.id}`}>View Details</Link>
    </div>
  );
};

export default ServiceCard;
