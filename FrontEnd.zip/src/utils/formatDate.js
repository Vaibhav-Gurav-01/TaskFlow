import React from 'react'

function formatDate() {
  return (
    <div>formatDate</div>
  )
}

export default formatDate