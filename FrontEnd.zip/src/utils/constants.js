import React from 'react'

function constants() {
  return (
    <div>constants</div>
  )
}

export default constants