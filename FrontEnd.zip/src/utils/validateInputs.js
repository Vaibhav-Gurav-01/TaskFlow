import React from 'react'

function validateInputs() {
  return (
    <div>validateInputs</div>
  )
}

export default validateInputs