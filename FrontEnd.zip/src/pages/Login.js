
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";  // Import the useAuth hook
import "../assets/styles/Login.css";
import "../assets/styles/Logo.css";


//   const { login, user, isAdmin, isVendor } = useAuth(); // Use the auth context
//   const [firstName, setFirstName] = useState("");
//   const [lastName, setLastName] = useState("");
//   const [phoneNumber, setPhoneNumber] = useState("");
//   const [email, setEmail] = useState("");
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [confirmPassword, setConfirmPassword] = useState("");
//   const [role, setRole] = useState("");
//   const [error, setError] = useState("");
//   const [currentForm, setCurrentForm] = useState("options");  // Track which form is shown
//   const [isSignupSuccess, setIsSignupSuccess] = useState(false); // Track if signup is successful
//   const navigate = useNavigate();

//   useEffect(() => {
//     // Redirect if user is already logged in
//     if (user) {
//       if (isAdmin()) {
//         navigate("/admin");
//       } else if (isVendor()) {
//         navigate("/vendor-dashboard");
//       } else {
//         navigate("/userhome");
//       }
//     }
//   }, [user, isAdmin, isVendor, navigate]);

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     // Validate credentials against localStorage data
//     const storedUser = JSON.parse(localStorage.getItem("user"));

//     if (storedUser && storedUser.username === username && storedUser.password === password) {
//       // Successful login
//       setError("");  // Reset error message
//       alert("Login successful!");  // Display alert on success
//       navigate("/userhome");  // Redirect to user home
//     } else {
//       // Invalid credentials
//       setError("Invalid credentials!");
//     }
//   };

//   const handleSignUp = (e) => {
//     e.preventDefault();
//     const newUser = {
//       firstName,
//       lastName,
//       phoneNumber,
//       email,
//       username,
//       password,
//       role,
//     };

//     // Save user to localStorage
//     localStorage.setItem("user", JSON.stringify(newUser));
//     alert("Signup successful! Please select your role.");  // Display alert on success
//     setIsSignupSuccess(true);  // Set signup success to true
//   };

//   const handleRoleSelection = (selectedRole) => {
//     const newUser = JSON.parse(localStorage.getItem("user"));
//     newUser.role = selectedRole; // Assign the selected role to the user

//     // Update localStorage with the role
//     localStorage.setItem("user", JSON.stringify(newUser));

//     // Redirect to appropriate page based on role
//     if (selectedRole === "admin") {
//       navigate("/admin");
//     } else if (selectedRole === "vendor") {
//       navigate("/vendor-dashboard");
//     } else {
//       navigate("/userhome");
//     }
//   };

//   const showForm = (form) => {
//     setFirstName("");
//     setLastName("");
//     setPhoneNumber("");
//     setEmail("");
//     setUsername("");
//     setPassword("");
//     setConfirmPassword("");
//     setError("");
//     setCurrentForm(form);  // Switch between login, signup, and vendor login forms
//   };

//   return (
//     <div className="container d-flex justify-content-center align-items-center vh-100">
//       {currentForm === "options" && (
//         <div className="form-container text-center">
//           <Link className="logo-link" to="/">
//             <h1 className="h2 mb-0 logo-link">One-Click Services</h1>
//           </Link>
//           <button className="btn btn-primary w-100 my-2" onClick={() => showForm("signup")}>Sign up</button>
//           <button className="btn btn-outline-secondary w-100" onClick={() => showForm("login")}>Log in</button>
//           <button className="btn btn-outline-secondary w-100 my-2" onClick={() => showForm("vendorLogin")}>Vendor Login</button>
//         </div>
//       )}

//       {/* Login form */}
//       {currentForm === "login" && (
//         <div className="form-container">
//           <h1 className="form-header">Log in</h1>
//           <form onSubmit={handleSubmit}>
//             <input
//               type="text"
//               className="form-control"
//               placeholder="Username or Email"
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//             />
//             <input
//               type="password"
//               className="form-control"
//               placeholder="Password"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//             />
//             <button type="submit" className="btn btn-primary w-100">Login</button>
//             {error && <div className="error-message">{error}</div>}
//             <p className="mt-3 text-center">
//               New user? <a href="#" onClick={() => showForm("signup")}>Create an account</a>
//             </p>
//           </form>
//         </div>
//       )}

//       {/* Vendor login form */}
//       {currentForm === "vendorLogin" && (
//         <div className="form-container">
//           <h1 className="form-header">Vendor Log in</h1>
//           <form onSubmit={handleSubmit}>
//             <input
//               type="text"
//               className="form-control"
//               placeholder="Username or Email"
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//             />
//             <input
//               type="password"
//               className="form-control"
//               placeholder="Password"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//             />
//             <button type="submit" className="btn btn-primary w-100">Vendor Login</button>
//             {error && <div className="error-message">{error}</div>}
//           </form>
//         </div>
//       )}

//       {/* Signup form */}
//       {currentForm === "signup" && (
//         <div className="form-container">
//           <h1 className="form-header">Sign up</h1>
//           <form onSubmit={handleSignUp}>
//             <input
//               type="text"
//               className="form-control"
//               placeholder="First Name"
//               value={firstName}
//               onChange={(e) => setFirstName(e.target.value)}
//             />
//             <input
//               type="text"
//               className="form-control"
//               placeholder="Last Name"
//               value={lastName}
//               onChange={(e) => setLastName(e.target.value)}
//             />
//             <input
//               type="email"
//               className="form-control"
//               placeholder="Email Address"
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}
//             />
//             <input
//               type="tel"
//               className="form-control"
//               placeholder="Phone Number"
//               value={phoneNumber}
//               onChange={(e) => setPhoneNumber(e.target.value)}
//             />
//             <input
//               type="text"
//               className="form-control"
//               placeholder="Username"
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//             />
//             <input
//               type="password"
//               className="form-control"
//               placeholder="Password"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//             />
//             <input
//               type="password"
//               className="form-control"
//               placeholder="Confirm Password"
//               value={confirmPassword}
//               onChange={(e) => setConfirmPassword(e.target.value)}
//             />
//             <button type="submit" className="btn btn-primary w-100">Create account</button>
//             {error && <div className="error-message">{error}</div>}
//           </form>
//         </div>
//       )}

//       {/* Role selection after successful signup */}
//       {isSignupSuccess && (
//         <div className="form-container">
//           <h1 className="form-header">Select Your Role</h1>
//           <button className="btn btn-outline-primary w-100" onClick={() => handleRoleSelection("user")}>User</button>
//           <button className="btn btn-outline-success w-100 my-2" onClick={() => handleRoleSelection("vendor")}>Vendor</button>
//           <button className="btn btn-outline-danger w-100" onClick={() => handleRoleSelection("admin")}>Admin</button>
//         </div>
//       )}
//     </div>
//   );
// };


const Login = () => {
  const { login, user, isAdmin, isVendor } = useAuth(); // Use the auth context
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState(""); // Store selected role
  const [error, setError] = useState("");
  const [currentForm, setCurrentForm] = useState("options");  // Track which form is shown
  const [isSignupSuccess, setIsSignupSuccess] = useState(false); // Track if signup is successful
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect if user is already logged in
    if (user) {
      if (isAdmin()) {
        navigate("/admin");
      } else if (isVendor()) {
        navigate("/vendor-dashboard");
      } else {
        navigate("/userhome");
      }
    }
  }, [user, isAdmin, isVendor, navigate]);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate credentials against localStorage data
    const storedUser = JSON.parse(localStorage.getItem("user"));

    if (storedUser && storedUser.username === username && storedUser.password === password) {
      // Successful login
      setError("");  // Reset error message
      alert("Login successful!");  // Display alert on success

      // Redirect based on role from localStorage
      const userRole = storedUser.role;
      if (userRole === "admin") {
        navigate("/admin"); // Redirect to admin dashboard
      } else if (userRole === "vendor") {
        navigate("/vendor-dashboard"); // Redirect to vendor dashboard
      } else {
        navigate("/userhome"); // Redirect to user home
      }
    } else {
      // Invalid credentials
      setError("Invalid credentials!");
    }
  };

  const handleSignUp = (e) => {
    e.preventDefault();

    if (!role) {
      setError("Please select a role");
      return;
    }

    const newUser = {
      firstName,
      lastName,
      phoneNumber,
      email,
      username,
      password,
      role, // Save the selected role
    };

    // Save user to localStorage
    localStorage.setItem("user", JSON.stringify(newUser));
    alert("Signup successful! Please log in.");  // Display alert on success
    setIsSignupSuccess(true);  // Set signup success to true
    setCurrentForm("login");  // Switch to login form
  };

  const handleRoleSelection = (e) => {
    setRole(e.target.value); // Update selected role
  };

  const showForm = (form) => {
    setFirstName("");
    setLastName("");
    setPhoneNumber("");
    setEmail("");
    setUsername("");
    setPassword("");
    setConfirmPassword("");
    setError("");
    setRole("");  // Reset role selection
    setCurrentForm(form);  // Switch between login, signup, and vendor login forms
  };

  return (
    <div className="container d-flex justify-content-center align-items-center vh-100">
      {currentForm === "options" && (
        <div className="form-container text-center">
          <Link className="logo-link" to="/">
            <h1 className="h2 mb-0 logo-link">One-Click Services</h1>
          </Link>
          <button className="btn btn-primary w-100 my-2" onClick={() => showForm("signup")}>Sign up</button>
          <button className="btn btn-outline-secondary w-100" onClick={() => showForm("login")}>Log in</button>
          <button className="btn btn-outline-secondary w-100 my-2" onClick={() => showForm("vendorLogin")}>Vendor Login</button>
        </div>
      )}

      {/* Login form */}
      {currentForm === "login" && (
        <div className="form-container">
          <h1 className="form-header">Log in</h1>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              className="form-control"
              placeholder="Username or Email"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button type="submit" className="btn btn-primary w-100">Login</button>
            {error && <div className="error-message">{error}</div>}
            <p className="mt-3 text-center">
              New user? <a href="#" onClick={() => showForm("signup")}>Create an account</a>
            </p>
          </form>
        </div>
      )}

      {/* Vendor login form */}
      {currentForm === "vendorLogin" && (
        <div className="form-container">
          <h1 className="form-header">Vendor Log in</h1>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              className="form-control"
              placeholder="Username or Email"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button type="submit" className="btn btn-primary w-100">Vendor Login</button>
            {error && <div className="error-message">{error}</div>}
          </form>
        </div>
      )}

      {/* Signup form */}
      {currentForm === "signup" && (
        <div className="form-container">
          <h1 className="form-header">Sign up</h1>
          <form onSubmit={handleSignUp}>
            <input
              type="text"
              className="form-control"
              placeholder="First Name"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
            />
            <input
              type="text"
              className="form-control"
              placeholder="Last Name"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
            />
            <input
              type="email"
              className="form-control"
              placeholder="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              type="tel"
              className="form-control"
              placeholder="Phone Number"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
            />
            <input
              type="text"
              className="form-control"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <input
              type="password"
              className="form-control"
              placeholder="Confirm Password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />

            {/* Role Selection */}
            <div className="role-selection">
              <h3>Select Role:</h3>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="radio"
                  id="roleUser"
                  value="user"
                  checked={role === "user"}
                  onChange={handleRoleSelection}
                />
                <label className="form-check-label" htmlFor="roleUser">
                  User
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="radio"
                  id="roleVendor"
                  value="vendor"
                  checked={role === "vendor"}
                  onChange={handleRoleSelection}
                />
                <label className="form-check-label" htmlFor="roleVendor">
                  Vendor
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="radio"
                  id="roleAdmin"
                  value="admin"
                  checked={role === "admin"}
                  onChange={handleRoleSelection}
                />
                <label className="form-check-label" htmlFor="roleAdmin">
                  Admin
                </label>
              </div>
            </div>

            <button type="submit" className="btn btn-primary w-100">Create account</button>
            {error && <div className="error-message">{error}</div>}
          </form>
        </div>
      )}
    </div>
  );
};

export default Login;








