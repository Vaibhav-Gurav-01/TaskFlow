import React from 'react'

function VendorManagement() {
  return (
    <div>VendorManagement</div>
  )
}

export default VendorManagement