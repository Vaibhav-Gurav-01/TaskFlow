import React from "react";

function ServiceScheduling() {
  return <div>ServiceScheduling</div>;
}

export default ServiceScheduling;
