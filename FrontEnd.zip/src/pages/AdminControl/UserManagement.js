import React from "react";

function UserManagement() {
  return <div>UserManagement</div>;
}

export default UserManagement;
