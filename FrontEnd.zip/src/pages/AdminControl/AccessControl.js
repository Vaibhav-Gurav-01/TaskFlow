import React from 'react'

function AccessControl() {
  return (
    <div>AccessControl</div>
  )
}

export default AccessControl