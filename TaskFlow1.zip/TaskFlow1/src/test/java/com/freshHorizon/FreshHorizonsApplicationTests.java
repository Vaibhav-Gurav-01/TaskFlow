package com.freshHorizon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreshHorizonsApplicationTests {

	@Test
	void contextLoads() {
	}

}
