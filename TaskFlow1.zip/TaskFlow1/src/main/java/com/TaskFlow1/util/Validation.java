package com.TaskFlow1.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.util.CollectionUtils;

import com.TaskFlow1.dao.RoleRepository;
import com.TaskFlow1.dao.UserRepository;
import com.TaskFlow1.dto.UserDto;


@Component
public class Validation {
	
	@Autowired
	private RoleRepository roleRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	public static final String EMAIL_REGEX = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
	public static final String PASSWORD_REGEX = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
	public static final String MOBILE_REGEX = "^(\\+\\d{1,3}[- ]?)?\\d{10}$";
	
	
	
	public void validateUser(UserDto user) {
		if(!StringUtils.hasText(user.getFirstName())) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		
		if(!StringUtils.hasText(user.getLastName())) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		
		if(!StringUtils.hasText(user.getEmail())  || !user.getEmail().matches(EMAIL_REGEX)) {
			throw new IllegalArgumentException("Invalid Email");
		}else if(userRepo.existsByEmail(user.getEmail())){
			throw new IllegalArgumentException("EmailAlready used, provide different email");
		}
		
		if(!StringUtils.hasText(user.getPassword())  || !user.getPassword().matches(PASSWORD_REGEX)) {
			throw new IllegalArgumentException("Invalid Password");
		}
		
		if(!StringUtils.hasText(user.getMobile())  || !user.getMobile().matches(MOBILE_REGEX)) {
			throw new IllegalArgumentException("Invalid Mobile");
		}
		
		if(CollectionUtils.isEmpty(user.getRoles())) {
			throw new IllegalArgumentException("Invalid Mobile"); 
		}else {
			List<Integer> availableRoleIds = roleRepo.findAll().stream().map(role-> role.getId()).toList();
			List<Integer> invalidRoleIds = user.getRoles().stream().map(role -> role.getId()).filter(roleId -> !availableRoleIds.contains(roleId)).toList();
			
			
			if(!CollectionUtils.isEmpty(invalidRoleIds)) {
				throw new IllegalArgumentException("Invalid Mobile"); 
			}
		}
	}
}
