package com.TaskFlow1.service;

public interface IHomeService {
	String verifyAccount(Integer id, String code);
}
