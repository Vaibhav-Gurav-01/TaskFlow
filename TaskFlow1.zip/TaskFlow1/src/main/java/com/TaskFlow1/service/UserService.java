package com.TaskFlow1.service;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.TaskFlow1.config.security.CustomUserDetails;
import com.TaskFlow1.dao.RoleRepository;
import com.TaskFlow1.dao.UserRepository;
import com.TaskFlow1.dto.EmailRequest;
import com.TaskFlow1.dto.LoginRequest;
import com.TaskFlow1.dto.LoginResponse;
import com.TaskFlow1.dto.UserDto;
import com.TaskFlow1.entity.AccountStatus;
import com.TaskFlow1.entity.Role;
import com.TaskFlow1.entity.User;
import com.TaskFlow1.exception.AccountInActiveException;
import com.TaskFlow1.exception.ResourceNotFoundException;
import com.TaskFlow1.util.Validation;

import jakarta.mail.MessagingException;

@Service
public class UserService implements IUserService{
	
	@Autowired
	private Validation validation;
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private RoleRepository roleRepo;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private PasswordEncoder encoder;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private IJwtService jwtService;
	
	
	@Override
	public Boolean register(UserDto userDto) throws UnsupportedEncodingException, MessagingException {
		
		validation .validateUser(userDto);
		User newUser = mapper.map(userDto, User.class);
		
		setRoles(userDto, newUser);
		
		setStatus(newUser);
		newUser.setIsDeleted(false);
		
		newUser.setPassword(encoder.encode(newUser.getPassword()));
		
		User savedUser = userRepo.save(newUser);
		
		if(!ObjectUtils.isEmpty(savedUser)) {
			accountConfirmationMail(savedUser);
			return true;
		}
		return false;
	}
	
	private void accountConfirmationMail(User savedUser) throws UnsupportedEncodingException, MessagingException {
		
		String msg = "<h1>Hello [[fName]]</h1>"
				+ "<h5>Your account created successfully.</h5>"
				+ "<p>to activate account <a href=[[URL]]>Click here</a></p><br/>"
				+ "<b>Thank you for joining us.</b>";
		
		String verificationCode = savedUser.getStatus().getVerificationCode();
		String verifyUrl = "http://localhost:7887/api/home/verify?userId="+savedUser.getId()+"&code="+verificationCode;
		
		msg = msg.replace("[[fName]]", savedUser.getFirstName());
		msg = msg.replace("[[URL]]", verifyUrl);
	
		EmailRequest emailRequest=EmailRequest.builder()
				.to(savedUser.getEmail())
				.subject("Account created Successfully!!")
				.title("Account confirmation mail")
				.message(msg)
				.build();
				emailService.sendEmail(emailRequest);
	}

	private void setRoles(UserDto userDto, User newUser) {
		List <Integer> roleIds = userDto.getRoles().stream().map(role-> role.getId()).toList();
		List<Role> roles = roleRepo.findAllById(roleIds);
		newUser.setRoles(roles);
	}
	
	@Override
	public List<UserDto> getAllUser() {
		List<UserDto> users = userRepo.findAllByIsDeletedFalse().stream().map(user -> mapper.map(user, UserDto.class)).toList();
		return users;
	}
	
	private void setStatus(User newUser) {
		AccountStatus status = new AccountStatus();
		status .setIsActive(false);
		status.setVerificationCode(UUID.randomUUID().toString());
		newUser.setStatus(status);
	}

	@Override
	public String deleteUserById(Integer id) {
		User foundUser = userRepo.findById(id).orElseThrow(()-> new ResourceNotFoundException("User Not found for id : "+ id));
		//userRepo.delete(foundUser);
		foundUser.setIsDeleted(true);
		foundUser.setEmail(null);
		userRepo.save(foundUser);
		return "User deleted Succefully";
	}

	@Override
	public LoginResponse login(LoginRequest loginRequest) {
		User foundUser = userRepo.findByEmail(loginRequest.getEmail()).orElseThrow(()-> new ResourceNotFoundException("User Not Found"));
		if(foundUser.getStatus().getIsActive()) {
			Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
			if(authenticate.isAuthenticated()) {
				
				
				CustomUserDetails userDetails = (CustomUserDetails) authenticate.getPrincipal();
				User authenticatedUser = userDetails.getUser();
				String token = jwtService.generateJwToken(authenticatedUser);
				return LoginResponse.builder()
						.token(token)
						.userDto(mapper.map(authenticatedUser, UserDto.class))
						.build();
			}else {
				throw new BadCredentialsException("Invalid Credentials!...");
			}
		}else {
			throw new AccountInActiveException("Cant login, Verify your email.....");
		}
		
	}
	
	
	
	
}
