package com.TaskFlow1.service;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.TaskFlow1.dto.LoginRequest;
import com.TaskFlow1.dto.LoginResponse;
import com.TaskFlow1.dto.UserDto;

import jakarta.mail.MessagingException;

public interface IUserService {
	List<UserDto> getAllUser();
	
	Boolean register(UserDto user) throws UnsupportedEncodingException, MessagingException;
	
	String deleteUserById(Integer id);
	
	LoginResponse login(LoginRequest loginRequest);
}
