package com.TaskFlow1.service;

import org.springframework.security.core.userdetails.UserDetails;

import com.TaskFlow1.entity.User;

public interface IJwtService {
	String generateJwToken(User user);
	
	String extractUserName(String token);
	
	Boolean validateToken(String token, UserDetails userDetails);
}
