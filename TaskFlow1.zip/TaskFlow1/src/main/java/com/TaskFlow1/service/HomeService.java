package com.TaskFlow1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TaskFlow1.dao.UserRepository;
import com.TaskFlow1.entity.User;
import com.TaskFlow1.exception.ResourceNotFoundException;

@Service
public class HomeService implements IHomeService {

	@Autowired
	private UserRepository userRepo;
	
	@Override
	public String verifyAccount(Integer id, String code) {
		User foundUser = userRepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Invalid User!.."));
		
		if(code.equals(foundUser.getStatus().getVerificationCode())) {
			foundUser.getStatus().setIsActive(true);
			foundUser.getStatus().setVerificationCode(null);
			userRepo.save(foundUser);
			return "Account verified successfully!..";
		}else if(foundUser.getStatus().getVerificationCode()== null){
			return "Account already verify";
		}
		return "Verification Failed!..";
	}
}
