package com.TaskFlow1.exception;

public class AccountInActiveException extends RuntimeException {

	public AccountInActiveException(String message) {
		super(message);
	}
	
}