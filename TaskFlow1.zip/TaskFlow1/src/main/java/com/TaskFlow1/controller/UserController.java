package com.TaskFlow1.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.TaskFlow1.dto.UserDto;
import com.TaskFlow1.service.IUserService;



@RestController
@RequestMapping("/api/user")
public class UserController {
	
	private IUserService userService;
	
	public UserController(IUserService userService) {
        this.userService = userService;
    }
	
	@GetMapping("/all")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<?> allUsers(){
		List<UserDto> allUsers = userService.getAllUser();
		if(CollectionUtils.isEmpty(allUsers)) {
			//return ResponseEntity.ok(allUsers);
			return new ResponseEntity<>("Users not available", HttpStatus.NO_CONTENT);
		}
		return ResponseEntity.ok(allUsers);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteUserById(@PathVariable Integer id){
		return ResponseEntity.ok(userService.deleteUserById(id));
	}
	
	
	@GetMapping("/forAdmin")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<?> endPointAdmin(){
		return ResponseEntity.ok("Authorized Admin can access the data");
	}
	
	@GetMapping("/forUser")
	@PreAuthorize("hasRole('User')")
	public ResponseEntity<?> endPointFarmer(){
		return ResponseEntity.ok("Authorized User can access the data");
	}
	
//	@GetMapping("/forBuyer")
//	@PreAuthorize("hasRole('Buyer')")
//	public ResponseEntity<?> endPointBuyer(){
//		return ResponseEntity.ok("Authorized Buyer can access thr data");
//	}
	
	@GetMapping("/forAll")
	@PreAuthorize("hasAnyRole('Admin', 'User')")
	public ResponseEntity<?> endPointforAllRoles(){
		return ResponseEntity.ok("Authorized All Roles can access the data");
	}
}
