package com.TaskFlow1.controller;

import java.io.UnsupportedEncodingException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.TaskFlow1.dto.LoginRequest;
import com.TaskFlow1.dto.LoginResponse;
import com.TaskFlow1.dto.UserDto;
import com.TaskFlow1.service.IUserService;

import jakarta.mail.MessagingException;


@RestController
@RequestMapping("/api/auth")
public class AuthController {
	
	private IUserService userService;

	public AuthController(IUserService userService) {
        this.userService = userService;
    }
	
//	http://localhost:7887/api/auth/register
	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody UserDto userDto) throws UnsupportedEncodingException, MessagingException{
		Boolean isRegistered = userService.register(userDto);
		if(isRegistered) {
			return new ResponseEntity<>("User Registered successfully", HttpStatus.CREATED);
		}else {
			return new ResponseEntity<>("User Registration  unSuccessfull", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
//	http://localhost:7887/api/auth/login
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody LoginRequest loginRequest) {
		LoginResponse loginResponse = userService.login(loginRequest);
		return ResponseEntity.ok(loginResponse);
	}
}
