package com.TaskFlow1.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.TaskFlow1.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {
	
}
